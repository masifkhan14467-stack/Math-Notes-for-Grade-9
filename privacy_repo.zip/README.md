# Math Notes for Grade 9 - Privacy Policy

This repository hosts the **Privacy Policy** for the *Math Notes for Grade 9* Android app.

📌 **App Developer:** M. Asif Bhuttah  
📌 **Technical Support:** ChatGPT (OpenAI)  
📌 **Contact:** masifkhan14467@gmail.com  

---

🔗 The Privacy Policy is available at:  
[Privacy Policy](./privacy_policy.html)

You can use this link for **Google Play Store** submission.
