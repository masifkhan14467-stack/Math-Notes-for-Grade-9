# Privacy Policy - Math Notes for Grade 9

This repository contains the Privacy Policy for the **Math Notes for Grade 9** Android app.

- App Developer: **M. Asif Bhuttah**
- Contact Email: **masifkhan14467@gmail.com**
- Technical Support: **ChatGPT (OpenAI)**

📄 [Click here to view the Privacy Policy](privacy_policy.html)
